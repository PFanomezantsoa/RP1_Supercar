<?php
session_start();
include '../connexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    $res = $mysqli->query("SELECT * FROM admin WHERE username='$user' AND password='$pass'");
    if ($res->num_rows == 1) {
        $_SESSION['admin'] = $user;
        header("Location: dashboard.php");
    } else {
        $error = "Identifiants incorrects";
    }
}
?>
<form method="post">
    <h2>Login Admin</h2>
    <label>Utilisateur :</label><input type="text" name="username" required><br>
    <label>Mot de passe :</label><input type="password" name="password" required><br>
    <button type="submit">Se connecter</button>
</form>
<?php if (!empty($error)) echo "<p style='color:red'>$error</p>"; ?>
