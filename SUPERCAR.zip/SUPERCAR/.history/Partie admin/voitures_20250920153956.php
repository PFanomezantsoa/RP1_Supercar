<?php
session_start();
if (!isset($_SESSION['admin'])) { header("Location: login.php"); exit; }
include '../connexion.php';

$res = $mysqli->query("SELECT * FROM cars");
?>
<h2>Gestion des voitures</h2>
<a href="add_car.php">Ajouter une voiture</a>
<table border="1" cellpadding="5">
    <tr><th>ID</th><th>Marque</th><th>Modèle</th><th>Année</th><th>Prix</th><th>Image</th><th>Actions</th></tr>
    <?php while($car = $res->fetch_assoc()): ?>
    <tr>
        <td><?= $car['id'] ?></td>
        <td><?= $car['brand'] ?></td>
        <td><?= $car['model'] ?></td>
        <td><?= $car['year'] ?></td>
        <td><?= $car['price'] ?> €</td>
        <td><img src="../images/<?= $car['image'] ?>" width="100"></td>
        <td>
            <a href="edit_car.php?id=<?= $car['id'] ?>">Modifier</a> |
            <a href="delete_car.php?id=<?= $car['id'] ?>" onclick="return confirm('Supprimer ?')">Supprimer</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
