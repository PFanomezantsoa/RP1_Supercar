<?php include("../db.php"); 
// Démarrer la session seulement si elle n'existe pas déjà
if(session_status() == PHP_SESSION_NONE){
    session_start();
}

// Vérifier si admin connecté
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
$result = $mysqli->query("SELECT * FROM cars");
?>
<!DOCTYPE html>
<html>
<head><title>Gérer les voitures</title></head>
<body>
<h2>Voitures</h2>
<a href="add_car.php">Ajouter une voiture</a><br><br>
<table border="1">
<tr><th>Marque</th><th>Modèle</th><th>Année</th><th>Prix</th><th>Image</th><th>Action</th></tr>
<?php while($row = $result->fetch_assoc()): ?>
<tr>
    <td><?= $row["brand"] ?></td>
    <td><?= $row["model"] ?></td>
    <td><?= $row["year"] ?></td>
    <td><?= $row["price"] ?> €</td>
    <td><img src="../images/<?= $row["image"] ?>" width="100"></td>
    <td>
        <a href="edit_car.php?id=<?= $row["id"] ?>">Modifier</a> | 
        <a href="delete_car.php?id=<?= $row["id"] ?>">Supprimer</a>
    </td>
</tr>
<?php endwhile; ?>
</table>
</body>
</html>
