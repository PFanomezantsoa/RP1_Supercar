<?php
session_start();
if (!isset($_SESSION['admin'])) { header("Location: login.php"); exit; }
include '../connexion.php';

$id = $_GET['id'];
$mysqli->query("DELETE FROM cars WHERE id=$id");
header("Location: voitures.php");
?>
