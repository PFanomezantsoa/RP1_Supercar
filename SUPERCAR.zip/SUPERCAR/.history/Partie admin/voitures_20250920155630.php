<?php
include("connexion.php");
$result = $mysqli->query("SELECT * FROM cars");
?>
<table border="1">
<tr><th>Marque</th><th>Modèle</th><th>Année</th><th>Prix</th><th>Image</th></tr>
<?php while($row = $result->fetch_assoc()): ?>
<tr>
    <td><?= $row['brand'] ?></td>
    <td><?= $row['model'] ?></td>
    <td><?= $row['year'] ?></td>
    <td><?= $row['price'] ?> €</td>
    <td><img src="images/<?= $row['image'] ?>" width="200"></td>
</tr>
<?php endwhile; ?>
</table>
