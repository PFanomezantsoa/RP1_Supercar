<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
?>
<h2>Tableau de bord</h2>
<p>Bienvenue <?php echo $_SESSION['admin']; ?> !</p>
<nav>
    <a href="voitures.php">Gérer les voitures</a> |
    <a href="essais.php">Voir les demandes d’essai</a> |
    <a href="logout.php">Déconnexion</a>
</nav>
