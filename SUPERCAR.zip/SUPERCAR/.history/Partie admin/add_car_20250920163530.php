<?php
include("../bd.php");

// Démarrer la session seulement si elle n'existe pas déjà
if(session_status() == PHP_SESSION_NONE){
    session_start();
}

// Vérifier si admin connecté
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

// Si formulaire soumis
if($_SERVER["REQUEST_METHOD"] == "POST") {
    $brand = $_POST['brand'];
    $model = $_POST['model'];
    $year = $_POST['year'];
    $price = $_POST['price'];

    // Gestion upload image
    if(isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $image = $_FILES['image']['name'];
        $target = "../images/".$image;

        // Déplacer le fichier uploadé dans le dossier images
        move_uploaded_file($_FILES['image']['tmp_name'], $target);

        // Insérer en base
        $stmt = $mysqli->prepare("INSERT INTO cars (brand, model, year, price, image) VALUES (?,?,?,?,?)");
        $stmt->bind_param("ssids", $brand, $model, $year, $price, $image);
        $stmt->execute();
        header("Location: cars.php");
        exit;
    } else {
        $error = "Erreur upload image";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Ajouter une voiture</title></head>
<body>
<h2>Ajouter une voiture</h2>
<form method="post" enctype="multipart/form-data">
    Marque: <input type="text" name="brand" required><br>
    Modèle: <input type="text" name="model" required><br>
    Année: <input type="number" name="year" required><br>
    Prix: <input type="number" name="price" step="0.01" required><br>
    Image: <input type="file" name="image" required><br><br>
<a href="voitures.php"><button type="submit">Ajouter</button></a>
</form>
<?php if(isset($error)) echo "<p style='color:red'>$error</p>"; ?>
</body>
</html>
