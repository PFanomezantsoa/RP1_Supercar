<?php
include("../bd.php");

// Vérifier si admin connecté
if(!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

// Récupérer toutes les voitures
$result = $mysqli->query("SELECT * FROM cars");
?>
<!DOCTYPE html>
<html>
<head><title>Gérer les voitures</title></head>
<body>
<h2>Voitures</h2>
<a href="add_car.php">Ajouter une voiture</a><br><br>

<table border="1" cellpadding="5">
<tr>
    <th>Marque</th>
    <th>Modèle</th>
    <th>Année</th>
    <th>Prix</th>
    <th>Image</th>
    <th>Action</th>
</tr>

<?php while($row = $result->fetch_assoc()): ?>
<tr>
    <td><?= $row['brand'] ?></td>
    <td><?= $row['model'] ?></td>
    <td><?= $row['year'] ?></td>
    <td><?= $row['price'] ?> €</td>
    <td>
        <!-- Affichage de l'image -->
        <img src="../images/<?= $row['image'] ?>" width="150">
    </td>
    <td>
        <a href="edit_car.php?id=<?= $row['id'] ?>">Modifier</a> |
        <a href="delete_car.php?id=<?= $row['id'] ?>" onclick="return confirm('Supprimer cette voiture ?');">Supprimer</a>
    </td>
</tr>
<?php endwhile; ?>

</table>
</body>
</html>
