<?php
session_start();
if (!isset($_SESSION['admin'])) { header("Location: login.php"); exit; }
include '../bd.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $brand = $_POST['brand'];
    $model = $_POST['model'];
    $year = $_POST['year'];
    $price = $_POST['price'];
    $image = $_FILES['image']['name'];

    move_uploaded_file($_FILES['image']['tmp_name'], "../images/".$image);

    $mysqli->query("INSERT INTO cars (brand, model, year, price, image) 
                    VALUES ('$brand','$model','$year','$price','$image')");
    header("Location: voitures.php");
}
?>
<h2>Ajouter une voiture</h2>
<form method="post" enctype="multipart/form-data">
    Marque: <input type="text" name="brand" required><br>
    Modèle: <input type="text" name="model" required><br>
    Année: <input type="number" name="year" required><br>
    Prix: <input type="number" name="price" required><br>
    Image: <input type="file" name="image" required><br>
    <button type="submit">Ajouter</button>
</form>
