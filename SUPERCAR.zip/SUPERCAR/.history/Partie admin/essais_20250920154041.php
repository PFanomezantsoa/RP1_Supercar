<?php
session_start();
if (!isset($_SESSION['admin'])) { header("Location: login.php"); exit; }
include '../connexion.php';

if (isset($_POST['id'], $_POST['statut'])) {
    $id = $_POST['id'];
    $statut = $_POST['statut'];
    $mysqli->query("UPDATE essai SET statut='$statut' WHERE id=$id");
}

$res = $mysqli->query("SELECT * FROM essai");
?>
<h2>Demandes d’essai</h2>
<table border="1" cellpadding="5">
    <tr><th>ID</th><th>Nom</th><th>Email</th><th>Voiture</th><th>Date</th><th>Statut</th><th>Action</th></tr>
    <?php while($e = $res->fetch_assoc()): ?>
    <tr>
        <td><?= $e['id'] ?></td>
        <td><?= $e['nom'] ?></td>
        <td><?= $e['email'] ?></td>
        <td><?= $e['voiture'] ?></td>
        <td><?= $e['date'] ?></td>
        <td><?= $e['statut'] ?></td>
        <td>
            <form method="post">
                <input type="hidden" name="id" value="<?= $e['id'] ?>">
                <select name="statut">
                    <option>En attente</option>
                    <option>Validée</option>
                    <option>Refusée</option>
                </select>
                <button type="submit">Changer</button>
            </form>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
