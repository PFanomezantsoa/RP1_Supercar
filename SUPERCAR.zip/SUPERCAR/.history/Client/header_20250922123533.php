<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Supercar</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
    <h1>Supercar</h1>
    <nav>
        <a href="index.php">Accueil</a>
        <a href="voitures.php">Voitures</a>
        <a href="essai.php">Demande d’essai</a>
        <a href="services.php">Services</a>
        <a href="contact.php">Contact</a>
        <a href="signup.php">S'inscrire</a>
        <a href="login.php">Se connecter</a>        
        <a href="logout.php">Se déconnecter</a>
    </nav>
</header>
<main>
