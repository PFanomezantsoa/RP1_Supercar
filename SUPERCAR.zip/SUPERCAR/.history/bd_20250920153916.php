<?php
$mysqli = new mysqli("localhost", "root", "", "supercar");
if ($mysqli->connect_error) {
    die("Erreur connexion MySQL : " . $mysqli->connect_error);
}
?>
