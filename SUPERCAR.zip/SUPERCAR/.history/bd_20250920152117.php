<?php
// admin/db.php
session_start();

// CHANGE CES PARAMS si nécessaire
$db_host = "localhost";
$db_user = "root";
$db_pass = ""; // mot de passe root WAMP par défaut
$db_name = "scadmin";

$mysqli = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($mysqli->connect_errno) {
    die("Erreur de connexion MySQL: " . $mysqli->connect_error);
}
$mysqli->set_charset("utf8mb4");
