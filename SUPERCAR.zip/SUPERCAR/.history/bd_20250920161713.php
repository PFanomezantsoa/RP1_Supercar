<?php
$mysqli = new mysqli("localhost", "root", "", "super_car");
if ($mysqli->connect_error) {
    die("Erreur connexion MySQL : " . $mysqli->connect_error);
    session_start();
}
?>
