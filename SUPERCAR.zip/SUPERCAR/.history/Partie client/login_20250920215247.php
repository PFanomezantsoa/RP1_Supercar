<?php
session_start();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>
</head>
<body>
    <h2>Page de connexion</h2>
    <form method="post" action="login.php">
        <label>Email :</label>
        <input type="text" name="email" required><br><br>
        
        <label>Mot de passe :</label>
        <input type="password" name="password" required><br><br>
        
        <button type="submit">Se connecter</button>
    </form>
</body>
</html>
