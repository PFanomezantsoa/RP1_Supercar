<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php include 'header.php'; ?>
<section class="hero">
    <h2>Bienvenue chez Supercar</h2>
    <p>Découvrez les voitures de luxe : BMW, Porsche et Lamborghini.</p>
</section>
<?php include 'footer.php'; ?>
</body>
</html>

