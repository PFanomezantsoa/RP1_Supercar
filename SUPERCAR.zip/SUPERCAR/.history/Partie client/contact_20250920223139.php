<!DOCTYPE html>
<html>
<head>
    <title>Contact - Supercar</title>
    <link href='style.css' rel='stylesheet'>
</head>
<body>
<?php include 'header.php'; ?>
<h2>Contactez-nous</h2>

<!-- Carte de localisation simple avec Google Maps iframe -->
<iframe 
    src="https://www.google.com/maps?q=MCCI+Business+School,+Ebene,+Mauritius&output=embed" 
    width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>

<h3>Contactez nous directement :</h3>
<p>📍 Adresse : SUPERCAR - Ebéne City</p>
<p>📞 Téléphone : 548974</p>
<p>🕒 Horaire de travail : 8h-16h</p>
<p>📧 Email : contact@supercar.com</p>

<?php include 'footer.php'; ?>
</body>
</html>
