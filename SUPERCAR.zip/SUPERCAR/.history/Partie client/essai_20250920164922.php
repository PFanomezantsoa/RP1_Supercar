<?php
include("../bd.php");
if($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST['nom'];
    $email = $_POST['email'];
    $tel = $_POST['telephone'];
    $voiture = $_POST['voiture'];

    $stmt = $mysqli->prepare("INSERT INTO demandes (nom, email, telephone, voiture) VALUES (?,?,?,?)");
    $stmt->bind_param("ssss", $nom, $email, $tel, $voiture);
    $stmt->execute();
    $message = "Demande envoyée avec succès !";
}
?>
<!DOCTYPE html>
<html>
<head><title>Demande d'essai</title></head>
<body>
<h2>Demande d'essai</h2>
<?php if(isset($message)) echo "<p style='color:green'>$message</p>"; ?>
<form method="post">
    Nom: <input type="text" name="nom" required><br>
    Email: <input type="email" name="email" required><br>
    Téléphone: <input type="text" name="telephone" required><br>
    Voiture: 
    <select name="voiture" required>
        <option value="BMW M3">BMW M3</option>
        <option value="BMW X5">BMW X5</option>
        <option value="BMW Z4">BMW Z4</option>
        <option value="Porsche 911">Porsche 911</option>
        <option value="Porsche Cayenne">Porsche Cayenne</option>
        <option value="Porsche Panamera">Porsche Panamera</option>
        <option value="Lamborghini Huracan">Lamborghini Huracan</option>
        <option value="Lamborghini Aventador">Lamborghini Aventador</option>
        <option value="Lamborghini Urus">Lamborghini Urus</option>
    </select><br><br>
    <button type="submit">Envoyer</button>
</form>
</body>
</html>
