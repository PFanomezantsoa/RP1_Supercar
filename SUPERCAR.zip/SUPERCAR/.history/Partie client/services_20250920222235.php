<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Services - Supercar</title>
</head>
<body>
<h2>Nos Services</h2>

<ul>
    <li><strong>Vente de voitures de luxe :</strong> BMW, Porsche, Lamborghini.</li>
    <li><strong>Demande d’essai :</strong> Réservez un essai directement en ligne.</li>
    <li><strong>Service après-vente :</strong> Entretien et réparation de véhicules de luxe.</li>
    <li><strong>Personnalisation :</strong> Accessoires et customisation de votre voiture.</li>
    <li><strong>Conseil automobile :</strong> Assistance pour choisir la voiture qui vous convient.</li>
</ul>
<?php if($result->num_rows > 0): ?>
    <ul>
        <?php while($service = $result->fetch_assoc()): ?>
            <li>
                <strong><?= htmlspecialchars($service['nom']) ?> :</strong>
                <?= nl2br(htmlspecialchars($service['description'])) ?>
            </li>
        <?php endwhile; ?>
    </ul>
<?php else: ?>
    <p>Aucun service disponible pour le moment.</p>
<?php endif; ?>

<p>Pour toute demande ou information supplémentaire, <a href="contact.php">contactez-nous</a>.</p>
</body>
</html>
