<!DOCTYPE html>
<html>
<head>
    <title>Contact - Supercar</title>
    <link href='style.css' rel='stylesheet'>
</head>
<body>
<?php
include("../bd.php");
if(session_status() == PHP_SESSION_NONE){ session_start(); }

$message = "";

// Si le formulaire est soumis
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $nom = $_POST['nom'];
    $tel = $_POST['telephone'];
    $email = $_POST['email'];
    $msg = $_POST['message'];

    $stmt = $mysqli->prepare("INSERT INTO contact (nom, telephone, email, message) VALUES (?,?,?,?)");
    $stmt->bind_param("ssss", $nom, $tel, $email, $msg);

    if($stmt->execute()){
        $message = "<p style='color:green'>✅ Message envoyé avec succès !</p>";
    } else {
        $message = "<p style='color:red'>❌ Erreur lors de l'envoi.</p>";
    }
}
?>

<?php include 'header.php'; ?>

<h2>Contactez-nous</h2>

<iframe 
    src="https://www.google.com/maps?q=MCCI+Business+School,+Ebene,+Mauritius&output=embed" 
    width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>

<h3>Contactez nous directement :</h3>
<p>📍 Adresse : SUPERCAR - Ebéne City</p>
<p>📞 Téléphone : 548974</p>
<p>🕒 Horaire de travail : 8h-16h</p>
<p>📧 Email : contact@supercar.com</p>

<!-- Message de confirmation -->
<?php if(!empty($message)) echo $message; ?>

<!-- Formulaire de contact -->
<h3>Envoyez-nous un message</h3>
<form method="post" class="contact-form">
    <label>Nom :</label><br>
    <input type="text" name="nom" required><br><br>

    <label>Téléphone :</label><br>
    <input type="text" name="telephone"><br><br>

    <label>Email :</label><br>
    <input type="email" name="email" required><br><br>

    <label>Message :</label><br>
    <textarea name="message" rows="5" required></textarea><br><br>

    <button type="submit">Envoyer</button>
</form>

<?php include 'footer.php'; ?>
</body>
</html>
