<?php include 'header.php'; ?>
<h2>Nos Voitures</h2>

<section class="cars">

    <h3>BMW</h3>
    <div class="car">
        <img src="images/bmw-m3.jpg" alt="BMW M3">
        <h4>BMW M3</h4>
        <p>Puissance : 473 ch<br>0-100 km/h : 4,2 s<br>Prix : 80 000 €</p>
    </div>
    <div class="car">
        <img src="images/bmw-i8.jpg" alt="BMW i8">
        <h4>BMW i8</h4>
        <p>Puissance : 369 ch<br>0-100 km/h : 4,4 s<br>Prix : 120 000 €</p>
    </div>
    <div class="car">
        <img src="images/bmw-x6.jpg" alt="BMW X6 M">
        <h4>BMW X6 M</h4>
        <p>Puissance : 600 ch<br>0-100 km/h : 3,8 s<br>Prix : 110 000 €</p>
    </div>

    <h3>Porsche</h3>
    <div class="car">
        <img src="images/porsche-911.jpg" alt="Porsche 911">
        <h4>Porsche 911 Carrera</h4>
        <p>Puissance : 379 ch<br>0-100 km/h : 4,0 s<br>Prix : 105 000 €</p>
    </div>
    <div class="car">
        <img src="images/porsche-taycan.jpg" alt="Porsche Taycan">
        <h4>Porsche Taycan</h4>
        <p>Puissance : 530 ch<br>0-100 km/h : 3,2 s<br>Prix : 150 000 €</p>
    </div>
    <div class="car">
        <img src="images/porsche-cayenne.jpg" alt="Porsche Cayenne">
        <h4>Porsche Cayenne</h4>
        <p>Puissance : 460 ch<br>0-100 km/h : 4,9 s<br>Prix : 95 000 €</p>
    </div>

    <h3>Lamborghini</h3>
    <div class="car">
        <img src="images/lamborghini-aventador.jpg" alt="Lamborghini Aventador">
        <h4>Lamborghini Aventador</h4>
        <p>Puissance : 770 ch<br>0-100 km/h : 2,8 s<br>Prix : 400 000 €</p>
    </div>
    <div class="car">
        <img src="images/lamborghini-huracan.jpg" alt="Lamborghini Huracán">
        <h4>Lamborghini Huracán</h4>
        <p>Puissance : 640 ch<br>0-100 km/h : 3,1 s<br>Prix : 250 000 €</p>
    </div>
    <div class="car">
        <img src="images/lamborghini-urus.jpg" alt="Lamborghini Urus">
        <h4>Lamborghini Urus</h4>
        <p>Puissance : 650 ch<br>0-100 km/h : 3,6 s<br>Prix : 220 000 €</p>
    </div>

</section>
<?php include 'footer.php'; ?>
