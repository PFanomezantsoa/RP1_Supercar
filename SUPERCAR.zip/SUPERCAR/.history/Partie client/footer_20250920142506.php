</main>
<footer>
    <p>&copy; 2025 Supercar - Tous droits réservés</p>
</footer>
</body>
</html>
