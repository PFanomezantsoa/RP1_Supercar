<?php include 'header.php'; ?>
<h2>Contact</h2>
<form action="contact.php" method="post">
    <label>Nom :</label><input type="text" name="nom" required><br>
    <label>Email :</label><input type="email" name="email" required><br>
    <label>Message :</label><textarea name="message" required></textarea><br>
    <button type="submit">Envoyer</button>
</form>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    echo "<p>Merci ".$_POST['nom']." ! Nous avons bien reçu votre message.</p>";
}
?>
<?php include 'footer.php'; ?>
