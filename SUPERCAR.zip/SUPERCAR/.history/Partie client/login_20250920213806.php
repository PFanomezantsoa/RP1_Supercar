<?php
session_start();
include("../bd.php");
$message = '';

if($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $mysqli->prepare("SELECT * FROM users WHERE email=?");
    $stmt->bind_param("s",$email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if($user && password_verify($password, $user['password'])){
        $_SESSION['user'] = $user['username'];
        $_SESSION['id'] = $user['id'];
        header("Location: index.php"); // page d'accueil
        exit;
    } else {
        $message = "Email ou mot de passe incorrect.";
    }
}
?>
