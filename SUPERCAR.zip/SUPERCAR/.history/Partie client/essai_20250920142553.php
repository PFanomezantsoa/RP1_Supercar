<?php include 'header.php'; ?>
<h2>Demande d’essai</h2>
<form action="essai.php" method="post">
    <label>Nom :</label><input type="text" name="nom" required><br>
    <label>Email :</label><input type="email" name="email" required><br>
    <label>Voiture :</label>
    <select name="voiture">
        <option>BMW M3</option>
        <option>Porsche 911 Carrera</option>
        <option>Lamborghini Aventador</option>
    </select><br>
    <label>Date :</label><input type="date" name="date" required><br>
    <button type="submit">Envoyer</button>
</form>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    echo "<p>Merci ".$_POST['nom']." ! Votre demande d’essai pour ".$_POST['voiture']." a été enregistrée.</p>";
}
?>
<?php include 'footer.php'; ?>
