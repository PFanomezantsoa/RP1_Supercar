<?php
session_start();
include("../bd.php");
$message = '';

if($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $mysqli->prepare("SELECT * FROM users WHERE email=?");
    $stmt->bind_param("s",$email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if($user && password_verify($password, $user['password'])){
        $_SESSION['user'] = $user['username'];
        $_SESSION['id'] = $user['id'];
        header("Location: index.php"); // page d'accueil après login
        exit;
    } else {
        $message = "Email ou mot de passe incorrect.";
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Connexion</title></head>
<body>
<h2>Connexion</h2>
<?php if($message) echo "<p>$message</p>"; ?>
<form method="post">
    Email: <input type="email" name="email" required><br>
    Mot de passe: <input type="password" name="password" required><br>
    <button type="submit">Se connecter</button>
</form>
<p>Pas encore inscrit ? <a href="signup.php">Créer un compte</a></p>
</body>
</html>
