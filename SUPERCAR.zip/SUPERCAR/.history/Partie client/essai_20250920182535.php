<?php
include("../bd.php");

// Récupération de la voiture depuis le lien GET
$voiture_prefill = isset($_GET['voiture']) ? $_GET['voiture'] : '';

if($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST['nom'];
    $email = $_POST['email'];
    $tel = $_POST['telephone'];
    $voiture = $_POST['voiture'];

    $stmt = $mysqli->prepare("INSERT INTO demandes (nom, email, telephone, voiture) VALUES (?,?,?,?)");
    $stmt->bind_param("ssss", $nom, $email, $tel, $voiture);
    $stmt->execute();
    $message = "Demande envoyée avec succès !";
}
?>
<!DOCTYPE html>
<html>
<head><title>Demande d'essai</title></head>
<body>
<h2>Demande d'essai</h2>
<?php if(isset($message)) echo "<p style='color:green'>$message</p>"; ?>

<form method="post">
    Nom: <input type="text" name="nom" required><br>
    Email: <input type="email" name="email" required><br>
    Téléphone: <input type="text" name="telephone" required><br>

    Voiture: 
    <select name="voiture" required>
        <?php
        $voitures = [
            "BMW M3","BMW X5","BMW Z4",
            "Porsche 911","Porsche Cayenne","Porsche Panamera",
            "Lamborghini Huracan","Lamborghini Aventador","Lamborghini Urus"
        ];
        foreach($voitures as $v){
            $selected = ($v == $voiture_prefill) ? "selected" : "";
            echo "<option value=\"$v\" $selected>$v</option>";
        }
        ?>
    </select><br><br>

    <button type="submit">Envoyer</button>
</form>
</body>
</html>
